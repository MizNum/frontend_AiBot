export const Environment = {
    SEND_OTP_API:'http://localhost:3000/sendOtp',
    RESPONSE_API:'http://localhost:3000/bot-response',
    RELATIVE_PATH :'http://localhost:3000/',
    TRANSLATE_API :'http://localhost:3000/translate'


}

