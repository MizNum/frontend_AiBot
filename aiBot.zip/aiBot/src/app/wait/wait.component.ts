import { Component } from '@angular/core';

@Component({
  selector: 'app-wait',
  standalone: true,
  imports: [],
  templateUrl: './wait.component.html',
  styleUrl: './wait.component.css'
})
export class WaitComponent {

}
